import { HelmetData } from "react-helmet-async";

export const helmetData = new HelmetData({});

export const helmetContext = helmetData.context;
