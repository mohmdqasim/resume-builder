import * as PortalPrimitive from "@radix-ui/react-portal";

export const Portal = PortalPrimitive.Root;
